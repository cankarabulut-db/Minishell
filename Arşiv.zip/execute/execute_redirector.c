/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute_redirector.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fuyar <fuyar@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/11 19:44:43 by akar              #+#    #+#             */
/*   Updated: 2024/11/22 15:23:58 by fuyar            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void	fderror(char *str)
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(str, 2);
	if (is_directory(str))
		ft_putstr_fd(": Is a directory\n", 2);
	else if (!is_file(str))
		ft_putstr_fd(": No such file or directory\n", 2);
	else if (access(str, R_OK))
		ft_putstr_fd(": Permission denied\n", 2);
	g_global_exit = 1;
}

void	setup_redirections(t_shell *cmd)
{
	int	i;

	i = -1;
	while (cmd->org_rdr[++i])
	{
		if (cmd->fd_error)
			break ;
		if (cmd->org_rdr[i] == OUTPUT)
			setup_output_redirection(cmd);
		else if (cmd->org_rdr[i] == INPUT && ++i)
			setup_input_redirection(cmd);
		else if (cmd->org_rdr[i] == APPEND && ++i)
			setup_append_redirection(cmd);
	}
	cmd->cur_ap = 0;
	cmd->cur_i = 0;
	cmd->cur_o = 0;
}
